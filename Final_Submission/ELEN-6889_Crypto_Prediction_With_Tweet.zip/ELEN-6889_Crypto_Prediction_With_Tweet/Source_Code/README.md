# Source code

Please drop your final version source code in here, make sure it is executable.

**Pipeline notebook is executable for the front end**

**Running instruction for front-end:**

1. `npm install`
2. `npm start`
3. wait for the deployment of NodeJS, visit website on the local or public network with local machine IP at port `3000`



